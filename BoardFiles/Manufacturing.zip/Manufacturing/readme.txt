Readme.txt file for the Manufacturing directory.

Student Names: Shamseddin Elmasri, Ziyad Mekhemer
Student Numbers: 8682397, 8686024 
Phone Contact Information: 12266065520, 2899938598
Board Size: 9.184 x 6.04 inches
